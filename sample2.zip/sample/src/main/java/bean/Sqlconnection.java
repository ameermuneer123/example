package bean;

import java.sql.Connection;
import java.sql.DriverManager;

public class Sqlconnection {
public Connection getConnection() {
	Connection con=null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample","root","");
				
	}catch (Exception e) {
		e.printStackTrace();// TODO: handle exception
	}
	return con;
}
}
